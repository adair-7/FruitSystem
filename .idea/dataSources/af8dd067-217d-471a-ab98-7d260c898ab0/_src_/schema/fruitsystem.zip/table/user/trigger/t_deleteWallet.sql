CREATE TRIGGER `t_deleteWallet`
AFTER DELETE ON `user`
FOR EACH ROW
  BEGIN
    DELETE  FROM wallet WHERE wallet.userId=OLD.userId;
  END