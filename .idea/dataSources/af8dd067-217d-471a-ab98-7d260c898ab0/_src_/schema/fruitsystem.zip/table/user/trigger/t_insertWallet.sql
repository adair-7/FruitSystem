CREATE TRIGGER `t_insertWallet`
AFTER INSERT ON `user`
FOR EACH ROW
  BEGIN
    INSERT INTO wallet(userId,userName,walletPwd) VALUES(NEW.userId,NEW.userName,NEW.userPwd);
  END