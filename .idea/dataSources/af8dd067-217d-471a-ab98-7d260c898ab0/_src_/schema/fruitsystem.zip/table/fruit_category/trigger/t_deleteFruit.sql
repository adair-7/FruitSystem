CREATE TRIGGER `t_deleteFruit`
AFTER DELETE ON `fruit_category`
FOR EACH ROW
  BEGIN
    DELETE FROM fruit_stock WHERE fruit_stock.fruitId=OLD.fruitId;
  END