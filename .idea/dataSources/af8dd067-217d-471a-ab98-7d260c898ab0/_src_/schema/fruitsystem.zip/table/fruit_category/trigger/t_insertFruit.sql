CREATE TRIGGER `t_insertFruit`
AFTER INSERT ON `fruit_category`
FOR EACH ROW
  BEGIN
    INSERT INTO fruit_stock(fruitId,fruitName, stockTop, stockAccount) VALUES (NEW.fruitId,NEW.fruitName,200,0);
  END