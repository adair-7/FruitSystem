CREATE TRIGGER `t_insertOrder`
AFTER INSERT ON `orders`
FOR EACH ROW
  BEGIN
    INSERT INTO recommender(userId,fruitId,fruitNum) VALUES (NEW.userId,NEW.fruitId,NEW.fruitNum);
  END